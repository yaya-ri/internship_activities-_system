<?php

// $url = "https://www.googleapis.com/books/v1/volumes?q=''&orderBy=newest&maxResults=5&key=AIzaSyBzJa7EtGSrBTVC2Wvfmn7n1LvSF8PQPT4";
// $json = file_get_contents($url);
// $bookApi = json_decode($json);
?>

<!DOCTYPE html>
<html>
<head>
	<title>JSON Parser Google API</title>
</head>
<body style="padding-left: 20px; padding-top: 20px;">
<form method="GET" action="#" >
	<div>
		<label>Keyword</label>
		<input type="text" name="q" required="">
	</div>
	<div>
		<label>Categories</label>
		<input type="text" name="categories" >
	</div>
	<div>
		<label>Authors</label>
		<input type="text" name="Authors" >
	</div>
	<div>
		<label>Publisher</label>
		<input type="text" name="Authors" >
	</div>
	<button type="submit">Search</button>
</form>
</body>
</html>	
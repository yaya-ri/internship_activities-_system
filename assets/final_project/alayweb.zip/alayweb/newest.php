<?php

$url = "https://www.googleapis.com/books/v1/volumes?q=''&orderBy=newest&maxResults=5&key=AIzaSyBzJa7EtGSrBTVC2Wvfmn7n1LvSF8PQPT4";
$json = file_get_contents($url);
$bookApi = json_decode($json);
?>

<!DOCTYPE html>
<html>
<head>
	<title>JSON Parser Google API</title>
</head>
<body style="padding-left: 20px; padding-top: 20px;">
	<h1>Detail Buku</h1>
	<br>
	<table>
		<tr style="height: 40px;">
			<td width="50px">Number</td>
			<td>Cover Image</td>
			<td>Book Title</td>
			<td>Author</td>
			<td>Publisher</td>
			<td>Published Date</td>
		</tr>
		<?php 
		$j = 1;
		$items = $bookApi->items;
		for ($i=0; $i < sizeof($items); $i++) { ?>
		<tr style="height: 40px;">
			<td width="50px"> <?php echo $j ;?></td>
			<td><img src="<?php echo $items[$i]->volumeInfo->imageLinks->smallThumbnail; ?>"></td>
			<td> <?php echo $items[$i]->volumeInfo->title; ?></td>
			<td> 
				<?php 
				if(isset($items[$i]->volumeInfo->authors)){
					$authors = $items[$i]->volumeInfo->authors;
					for ($k=0; $k < sizeof($authors); $k++) {
						echo $authors[$k];
					} 
				} else {
					echo "none";
				}

				?>
			</td>
			<td>  
				<?php 
				if(isset($items[$i]->volumeInfo->publisher)){
					echo $items[$i]->volumeInfo->publisher;	
				} else {
					echo "none";
				}
				?>
			</td>
			<td> 
				<?php 
				if(isset($items[$i]->volumeInfo->publishedDate)){
					echo $items[$i]->volumeInfo->publishedDate;	
				} else {
					echo "none";
				}
				?> 
			</td>
		</tr>
		<?php $j++; } ?>
	</table>

</body>
</html>
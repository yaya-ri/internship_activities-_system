<?php 
	require_once("../proses/koneksi.php");
	require_once("../proses/cek_login_admin.php");
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../js/crud.js" ></script>
	<title>Dashboard</title>
</head>

<script type="text/javascript">
	$(document).ready(function(){

		function refreshTable() {
			$.ajax({    //create an ajax request to load_page.php
				type: "GET",
				url: "../proses/proses_tampil_anggota.php",   
				success: function(data){                    
					$("tbody#isi-table-anggota").html(data);
				}
	    	});
		}
		refreshTable();

		$("#form-tambah-anggota").submit(function() {
			var data_id = $("#tambah-id-anggota").val();
			var data_nama = $("#tambah-nama-anggota").val();
			var data_alamat = $("#tambah-alamat-anggota").val();
			var data_nohp = $("#tambah-nohp-anggota").val();
			$.ajax({    //create an ajax request to load_page.php
				type: "POST",
				url: "../proses/proses_tambah_anggota.php",             
				data: {id : data_id, nama : data_nama, alamat : data_alamat, nohp : data_nohp},
				success: function(data){
					refreshTable();
					$(".tambah-anggota-modal-lg").modal('hide');
					$("#form-tambah-anggota")[0].reset();
				}
	    	});
	    	return false;
		});

		$("#form-hapus-anggota").submit(function() {
			var data_id = $("#hapus-anggota-id").val();
			$.ajax({
				type : "POST",
				url : "../proses/proses_hapus_anggota.php",
				data : {id : data_id},
				success : function(data){
					refreshTable();
					$(".hapus-anggota-modal-lg").modal('hide');
					$("#form-hapus-anggota")[0].reset();
					alert("Data berhasil dihapus");
				}
			});
	    	return false;
		});

		$("#form-reset-anggota").submit(function() {
			var data_id = $("#reset-anggota-id").val();
			$.ajax({
				type : "POST",
				url : "../proses/proses_reset_password_anggota.php",
				data : {id : data_id},
				success : function(data){
					refreshTable();
					$(".reset-modal-lg").modal('hide');
					$("#form-reset-anggota")[0].reset();
					alert("Password berhasil direset");
				}
			});
	    	return false;
		});

	});
</script>

<body>
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">SIPS</a>
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="navbar-collapse collapse" id="navbar-main">
				<ul class="nav navbar-nav">
					<li class="active"><a href="#">Dashboard<span class="sr-only">(current)</span></a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right">
					<li><a href="../proses/proses_logout.php">Keluar</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="container isi">
		<div class="jumbotron">
			<h2 style="font-weight: bold">Admin <small> - Dashboard</small></h2>
		</div>
		
		<div class="row">
			<div class="row">
			<div class="col-md-2">
				<ul class="nav nav-pills nav-stacked">
					<li><a href="peminjaman.php">Peminjaman</a></li>
					<li><a href="buku.php">Buku</a></li>
					<li class="active"><a href="#">Anggota</a></li>
					<li><a href="informasi.php">Informasi</a></li>
					<li><a href="kritiksaran.php">Kritik Saran</a></li>
					<li><a href="melapor.php">Laporan</a></li>
					<li><a href="requestbuku.php">Permintaan Tambahan Buku</a></li>
				</ul>
			</div>
			<div class="col-md-10">
				<div class="panel panel-primary">
						<div class="panel-heading">
							<h4 class="panel-title">Daftar Anggota Perpustakaan
								<div class="btn-group pull-right">
									<a href="#" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".tambah-anggota-modal-lg"><span class="glyphicon glyphicon-plus"></span></a>
								</div>
							</h4>
							<div class="clearfix"></div>
						</div>
						<div class="panel-body">
							<form class="form-horizontal" id="table-anggota">
								<fieldset>
									<table class="table table-striped table-hover">
										<thead style="font-size: 14px">
											<tr>
												<th>ID</th>
												<th>Nama</th>
												<th>Alamat</th>
												<th>No Hp</th>
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody style="font-size: 13px" id="isi-table-anggota">
										</tbody>
									</table> 
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<br>
	<footer class="akhir">
		<div class="container">
			<br>
			<blockquote>Ini merupakan footer Sistem Informasi Perpustakaan Sekolah
				<small>Pengembangan Perangkat Lunak Agile</small>
			</blockquote>

			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
	</footer>

	<div class="modal fade tambah-anggota-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Tambah Data Anggota Perpustakaan</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" method="POST" id="form-tambah-anggota">
						<fieldset>
							<div class="form-group">
								<label class="col-lg-2 control-label">ID</label>
								<div class="col-lg-10">
									<input id="tambah-id-anggota" name="id" class="form-control" placeholder="Masukkan ID Anggota" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label class="col-lg-2 control-label">Nama</label>
								<div class="col-lg-10">
									<input id="tambah-nama-anggota" name="nama" class="form-control" placeholder="Masukkan Nama Anggota" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label class="col-lg-2 control-label">Alamat</label>
								<div class="col-lg-10">
									<input id="tambah-alamat-anggota" name="alamat" class="form-control" placeholder="Masukkan Alamat Anggota" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label class="col-lg-2 control-label">No Hp</label>
								<div class="col-lg-10">
									<input id="tambah-nohp-anggota" name="nohp" class="form-control" placeholder="Masukkan No Hp Anggota" type="text" required>
								</div>
							</div>
						</fieldset>
						<div class="modal-footer">
							<button name="submit" type="submit" class="btn btn-primary">Simpan Perubahan</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade reset-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Reset Password</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" id="form-reset-anggota" method="POST">
						<fieldset>
							<div class="form-group">
								<label class="col-lg-1 control-label">ID</label>
								<div class="col-lg-3">
									<input id="reset-anggota-id" name="id" class="form-control input-id-anggota" type="text" readonly>
								</div>
							</div>
							<p>Apakah Anda Yakin Untuk Mereset Password Anggota ?</p>
						</fieldset>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary btn-reset-password">Simpan Perubahan</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade hapus-anggota-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Hapus Data Anggota</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" id="form-hapus-anggota" method="POST">
						<fieldset>
							<div class="form-group">
								<label class="col-lg-1 control-label">ID</label>
								<div class="col-lg-3">
									<input id="hapus-anggota-id" name="id" class="form-control input-id-anggota" type="text" readonly>
								</div>
							</div>
							<p>Apakah Anda Yakin Untuk Menghapus Data Anggota ?</p>
						</fieldset>
						<div class="modal-footer">
							<button type="submit" class="btn btn-primary btn-hapus">Simpan Perubahan</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	</body>
</html>
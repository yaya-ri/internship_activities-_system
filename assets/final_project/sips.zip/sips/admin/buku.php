<?php 
	require_once("../proses/koneksi.php");
	require_once("../proses/cek_login_admin.php");
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../js/crud.js" ></script>

	<title>Dashboard</title>
</head>

<script type="text/javascript">
	$(document).ready(function(){

		function refreshTable() {
			$.ajax({    //create an ajax request to load_page.php
				type: "GET",
				url: "../proses/proses_tampil_buku.php",   
				success: function(data){                    
					$("tbody#isi-table-buku").html(data);
				}
	    	});
		}
		refreshTable();

		$("#form-tambah-buku").submit(function() {
			var data_judul = $("#input-tambah-judul-buku").val();
			var data_kategori = $("#input-tambah-kategori-buku").val();
			var data_pengarang = $("#input-tambah-pengarang-buku").val();
			var data_penerbit = $("#input-tambah-penerbit-buku").val();
			var data_tahun = $("#input-tambah-tahun-buku").val();
			var data_tanggal_masuk = $("#input-tambah-tanggal-masuk-buku").val();
			var data_stok = $("#input-tambah-stok-buku").val();
			var data_lokasi = $("#input-tambah-lokasi-buku").val();
			//alert(data_judul + data_kategori + data_pengarang + data_penerbit + data_tahun + data_tanggal_masuk + data_stok + data_lokasi);
			$.ajax({    //create an ajax request to load_page.php
				type: "POST",
				url: "../proses/proses_tambah_buku.php",             
				data: {judul : data_judul, kategori : data_kategori, pengarang : data_pengarang, penerbit : data_penerbit, tahun : data_tahun, tanggal_masuk : data_tanggal_masuk, stok : data_stok, lokasi : data_lokasi},
				success: function(data){
					refreshTable();
					$(".tambah-data-buku-modal-lg").modal('hide');
					$("#form-tambah-buku")[0].reset();
				}
	    	});
	    	return false;
		});

		$("#form-ubah-buku").submit(function() {
			var data_id = $(".input-id").val();
			var data_judul = $(".input-judul").val();
			var data_kategori = $(".input-kategori").val();
			var data_pengarang = $(".input-pengarang").val();
			var data_penerbit = $(".input-penerbit").val();
			var data_tahun = $(".input-tahun-terbit").val();
			var data_tanggal_masuk = $(".input-tanggal-masuk").val();
			var data_stok = $(".input-stok").val();
			var data_ketersediaan = $(".input-ketersediaan").val();
			var data_lokasi = $(".input-lokasi").val();
			//alert(data_id + data_judul + data_kategori + data_pengarang + data_penerbit + data_tahun + data_tanggal_masuk + data_stok + data_stok + data_lokasi);
			$.ajax({    //create an ajax request to load_page.php
				type: "POST",
				url: "../proses/proses_ubah_buku.php",             
				data: {id : data_id, judul : data_judul, kategori : data_kategori, pengarang : data_pengarang, penerbit : data_penerbit, tahun : data_tahun, tanggal_masuk : data_tanggal_masuk, stok : data_stok, ketersediaan : data_ketersediaan, lokasi : data_lokasi},
				success: function(data){
					refreshTable();
					$(".ubah-data-buku-modal-lg").modal('hide');
					$("#form-ubah-buku")[0].reset();
				}
	    	});
	    	return false;
		});

		$("#form-hapus-buku").submit(function() {
			var data_id = $("#input-hapus-id-buku").val();
			$.ajax({
				type : "POST",
				url : "../proses/proses_hapus_buku.php",
				data : {id : data_id},
				success : function(data){
					refreshTable();
					$(".hapus-data-buku-modal-lg").modal('hide');
					$("#form-hapus-buku")[0].reset();
					alert("Data berhasil dihapus");
				}
			});
	    	return false;
		});

	});
</script>

<body>
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">SIPS</a>
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="navbar-collapse collapse" id="navbar-main">
				<ul class="nav navbar-nav">
					<li class="active"><a href="#">Dashboard<span class="sr-only">(current)</span></a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right">
					<li><a href="../proses/proses_logout.php">Keluar</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="container isi">
		<div class="jumbotron">
			<h2 style="font-weight: bold">Admin <small> - Dashboard</small></h2>
		</div>

		<div class="row">
			<div class="row">
				<div class="col-md-2">
					<ul class="nav nav-pills nav-stacked">
						<li><a href="peminjaman.php">Peminjaman</a></li>
						<li class="active"><a href="#">Buku</a></li>
						<li><a href="anggota.php">Anggota</a></li>
						<li><a href="informasi.php">Informasi</a></li>
						<li><a href="kritiksaran.php">Kritik Saran</a></li>
						<li><a href="melapor.php">Laporan</a></li>
						<li><a href="requestbuku.php">Permintaan Tambahan Buku</a></li>
					</ul>
				</div>
				<div class="col-md-10">
					<div class="panel panel-primary">
						<div class="panel-heading">
							<h4 class="panel-title">Daftar Buku
								<div class="btn-group pull-right">
									<a data-href="#" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".tambah-data-buku-modal-lg"><span class="glyphicon glyphicon-plus"></span></a>
								</div>
							</h4>
							<div class="clearfix"></div>
						</div>
						<div class="panel-body">
							<form class="form-horizontal">
								<fieldset>
									<table class="table table-striped table-hover">
										<thead style="font-size: 14px">
											<tr>
												<th>ID</th>
												<th>Judul Buku</th>
												<th>Kategori</th>
												<th>Pengarang</th>
												<th>Penerbit</th>
												<th>Tahun Terbit</th>
												<th>Tgl Masuk</th>
												<th>Stok</th>
												<th>Available</th>
												<th>Lokasi</th>
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody style="font-size: 13px" id="isi-table-buku">
										</tbody>
									</table> 
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade hapus-data-buku-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Hapus Data Buku</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" id="form-hapus-buku" method="POST">
						<fieldset>
							<div class="form-group">
								<label class="col-lg-1 control-label">ID</label>
								<div class="col-lg-4">
									<input name="id" class="form-control" id="input-hapus-id-buku" type="text" required readonly>
								</div>
							</div>
							<p>Apakah Anda Yakin Untuk Menghapus Data Buku ?</p>
							<div class="modal-footer">
								<button type="submit" class="btn btn-primary btn-hapus">Simpan Perubahan</button>
								<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
							</div>
						</fieldset>
					</form>
				</div>
			</div>
		</div>
	</div>
	
	<div class="modal fade tambah-data-buku-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Tambah Data Buku</h4>
			</div>
			<div class="modal-body">
				<form class="form-horizontal" method="POST" id="form-tambah-buku">
					<fieldset>
						<div class="form-group">
							<label for="inputidentitas" class="col-lg-2 control-label">Judul Buku</label>
							<div class="col-lg-10">
								<input name="judul" class="form-control" id="input-tambah-judul-buku" placeholder="Masukkan Judul Buku" type="text" required>
							</div>
						</div>
						<div class="form-group">
							<label for="inputidentitas" class="col-lg-2 control-label">Kategori</label>
							<div class="col-lg-10">
								<input name="kategori" class="form-control" id="input-tambah-kategori-buku" placeholder="Masukkan Kategori Buku" type="text" required>
							</div>
						</div>
						<div class="form-group">
							<label for="inputidentitas" class="col-lg-2 control-label">Pengarang</label>
							<div class="col-lg-10">
								<input name="pengarang" class="form-control" id="input-tambah-pengarang-buku" placeholder="Masukkan Nama Pengarang Buku" type="text" required>
							</div>
						</div>
						<div class="form-group">
							<label for="inputidentitas" class="col-lg-2 control-label">Penerbit</label>
							<div class="col-lg-10">
								<input name="penerbit" class="form-control" id="input-tambah-penerbit-buku" placeholder="Masukkan Penerbit Buku" type="text" required>
							</div>
						</div>
						<div class="form-group">
							<label for="inputidentitas" class="col-lg-2 control-label">Tahun Terbit</label>
							<div class="col-lg-10">
								<input name="tahun" class="form-control" id="input-tambah-tahun-buku" placeholder="Masukkan Tahun Terbit Buku" type="text" required>
							</div>
						</div>
						<div class="form-group">
							<label for="inputidentitas" class="col-lg-2 control-label">Tanggal Masuk</label>
							<div class="col-lg-3">
								<input name="tanggal_masuk" class="form-control" id="input-tambah-tanggal-masuk-buku" type="date" required>
							</div>
						</div>
						<div class="form-group">
							<label for="inputidentitas" class="col-lg-2 control-label">Stok</label>
							<div class="col-lg-10">
								<input name="stok" class="form-control" id="input-tambah-stok-buku" placeholder="Masukkan Stok Buku" type="text" required>
							</div>
						</div>
						<div class="form-group">
							<label for="inputidentitas" class="col-lg-2 control-label">Lokasi</label>
							<div class="col-lg-10">
								<input name="lokasi" class="form-control" id="input-tambah-lokasi-buku" placeholder="Masukkan Lokasi Buku" type="text" required>
							</div>
						</div>
					</fieldset>
					<div class="modal-footer">
						<button name="submit" type="submit" class="btn btn-primary">Simpan Perubahan</button>
						<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
					</div>
				</form>
			</div>
		</div>
		</div>
	</div>

	<div class="modal fade ubah-data-buku-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Ubah Data Buku</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" method="POST" id="form-ubah-buku">
						<fieldset>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">ID Buku</label>
								<div class="col-lg-10">
									<input name="id" class="form-control input-id" type="text" required readonly>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Judul Buku</label>
								<div class="col-lg-10">
									<input name="judul" class="form-control input-judul" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Kategori</label>
								<div class="col-lg-10">
									<input name="kategori" class="form-control input-kategori" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Pengarang</label>
								<div class="col-lg-10">
									<input name="pengarang" class="form-control input-pengarang" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Penerbit</label>
								<div class="col-lg-10">
									<input name="penerbit" class="form-control input-penerbit" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Tahun Terbit</label>
								<div class="col-lg-10">
									<input name="tahun-terbit" class="form-control input-tahun-terbit" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Tanggal Masuk</label>
								<div class="col-lg-3">
									<input name="tanggal-masuk" class="form-control input-tanggal-masuk" type="date" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Stok</label>
								<div class="col-lg-10">
									<input name="stok" class="form-control input-stok" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Ketersediaan</label>
								<div class="col-lg-10">
									<input name="ketersediaan" class="form-control input-ketersediaan" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Lokasi</label>
								<div class="col-lg-10">
									<input name="lokasi" class="form-control input-lokasi" type="text" required>
								</div>
							</div>
						</fieldset>
						<div class="modal-footer">
							<button name="submit" type="submit" class="btn btn-primary">Simpan Perubahan</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<br>
	<footer class="akhir">
		<div class="container">
			<br>
			<blockquote>Ini merupakan footer Sistem Informasi Perpustakaan Sekolah
				<small>Pengembangan Perangkat Lunak Agile</small>
			</blockquote>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
	</footer>
</body>
</html>
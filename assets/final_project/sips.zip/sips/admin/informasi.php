<?php 
require_once("../proses/koneksi.php");
require_once("../proses/cek_login_admin.php");
?>
<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../js/crud.js"></script>
	<title>Dashboard</title>
</head>
<script type="text/javascript">
	$(document).ready(function(){

		refreshTable();

		function refreshTable(){
			$.ajax({    //create an ajax request to load_page.php
				type: "GET",
				url: "../proses/proses_tampil_informasi.php",   
				success: function(data){                    
					$("tbody#isi-table-informasi").html(data);
				}
	    	});
		}

		$("#form-tambah-informasi").submit(function() {
			var data_judul = $("#input-tambah-judul-info").val();
			var data_isi = $("#input-tambah-isi-info").val();
			//alert(data_judul + data_kategori + data_pengarang + data_penerbit + data_tahun + data_tanggal_masuk + data_stok + data_lokasi);
			$.ajax({    //create an ajax request to load_page.php
				type: "POST",
				url: "../proses/proses_tambah_info.php",             
				data: {judul : data_judul, isi : data_isi},
				success: function(data){
					refreshTable();
					$(".tambah-info-modal-lg").modal('hide');
					$("#form-tambah-informasi")[0].reset();
				}
	    	});
	    	return false;
		});

		$("#form-ubah-informasi").submit(function() {
			var data_id = $("#input-ubah-id-info").val();
			var data_judul = $("#input-ubah-judul-info").val();
			var data_isi = $("#input-ubah-isi-info").val();
			//alert(data_id + " " +data_judul + " " +data_isi);
			$.ajax({    //create an ajax request to load_page.php
				type: "POST",
				url: "../proses/proses_ubah_info.php",             
				data: {id : data_id, judul : data_judul, isi : data_isi},
				success: function(data){
					refreshTable();
					$(".ubah-info-modal-lg").modal('hide');
					$("#form-ubah-informasi")[0].reset();
				}
	    	});
	    	return false;
		});

		$("#form-hapus-informasi").submit(function() {
			var data_id = $("#input-hapus-id-info").val();
			$.ajax({
				type : "POST",
				url : "../proses/proses_hapus_info.php",
				data : {id : data_id},
				success : function(data){
					refreshTable();
					$(".hapus-info-modal-lg").modal('hide');
					$("#form-hapus-informasi")[0].reset();
					alert("Data berhasil dihapus");
				}
			});
	    	return false;
		});

	});
</script>
<body>
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">SIPS</a>
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="navbar-collapse collapse" id="navbar-main">
				<ul class="nav navbar-nav">
					<li class="active"><a href="#">Dashboard<span class="sr-only">(current)</span></a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right">
					<li><a href="../proses/proses_logout.php">Keluar</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="container isi">
		<div class="jumbotron">
			<h2 style="font-weight: bold">Admin <small> - Dashboard</small></h2>
		</div>

		<div class="row">
			<div class="row">
				<div class="col-md-2">
					<ul class="nav nav-pills nav-stacked">
						<li><a href="peminjaman.php">Peminjaman</a></li>
						<li><a href="buku.php">Buku</a></li>
						<li><a href="anggota.php">Anggota</a></li>
						<li class="active"><a href="#">Informasi</a></li>
						<li><a href="kritiksaran.php">Kritik Saran</a></li>
						<li><a href="melapor.php">Laporan</a></li>
						<li><a href="requestbuku.php">Permintaan Tambahan Buku</a></li>
					</ul>
				</div>
				<div class="col-md-10">
					<div class="panel panel-primary">
						<div class="panel-heading">
							<h4 class="panel-title">Informasi Perpustakaan
								<div class="btn-group pull-right">
									<a href="#" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".tambah-info-modal-lg"><span class="glyphicon glyphicon-plus"></span></a>
								</div>
							</h4>
							<div class="clearfix"></div>
						</div>
						<div class="panel-body">
							<form class="form-horizontal">
								<fieldset>
									<table class="table table-striped table-hover">
										<thead style="font-size: 14px">
											<tr>
												<th>ID</th>
												<th>Judul Informasi</th>
												<th>Isi</th>
												<th>Tanggal</th>
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody style="font-size: 13px" id="isi-table-informasi">
										</tbody>
									</table> 
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade hapus-info-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Hapus Informasi Perpustakaan</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" id="form-hapus-informasi" method="POST">
						<fieldset>
							<div class="form-group">
								<label class="col-lg-1 control-label">ID</label>
								<div class="col-lg-4">
									<input name="id" class="form-control" id="input-hapus-id-info" type="text" required readonly>
								</div>
							</div>
							<p>Apakah Anda Yakin Untuk Menghapus Informasi?</p>
							<div class="modal-footer">
								<button type="submit" class="btn btn-primary btn-hapus">Simpan Perubahan</button>
								<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
							</div>
						</fieldset>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade tambah-info-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Tambah Informasi Perpustakaan</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" method="POST" id="form-tambah-informasi">
						<fieldset>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Judul Informasi</label>
								<div class="col-lg-10">
									<input class="form-control" name="judul" placeholder="Masukkan Judul Informasi" type="text" id="input-tambah-judul-info" required>
								</div>
							</div>
							<div class="form-group">
								<label for="textArea" class="col-lg-2 control-label">Isi Informasi</label>
								<div class="col-lg-10">
									<textarea class="form-control" rows="3" name="isi" id="input-tambah-isi-info" placeholder="Masukkan Isi Informasi" required></textarea>
								</div>
							</div>
						</fieldset>
						<div class="modal-footer">
							<button name="tambah-info" type="submit" class="btn btn-primary">Simpan Perubahan</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade ubah-info-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Ubah Informasi Perpustakaan</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" method="POST" id="form-ubah-informasi">
						<fieldset>
							<div class="form-group">
								<label for="input" class="col-lg-2 control-label">ID</label>
								<div class="col-lg-10">
									<input id="input-ubah-id-info" class="form-control input-id" name="id" type="text" required readonly>
								</div>
							</div>
							<div class="form-group">
								<label for="input" class="col-lg-2 control-label">Judul Informasi</label>
								<div class="col-lg-10">
									<input id="input-ubah-judul-info" class="form-control input-judul" name="judul" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label class="col-lg-2 control-label" for="textArea">Isi Informasis</label>
								<div class="col-lg-10">
									<textarea id="input-ubah-isi-info" name="isi" class="form-control input-isi"></textarea>
								</div>
							</div>
						</fieldset>
						<div class="modal-footer">
							<button name="ubah-info" type="submit" class="btn btn-primary">Simpan Perubahan</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<br>

	<footer class="akhir">
		<div class="container">
			<br>
			<blockquote>Ini merupakan footer Sistem Informasi Perpustakaan Sekolah
				<small>Pengembangan Perangkat Lunak Agile</small>
			</blockquote>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			</div>
	</footer>

</body>
</html>
<?php 
	require_once("../proses/koneksi.php");
	require_once("../proses/cek_login_admin.php");
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../js/crud.js" ></script>
	<title>Dashboard</title>
</head>
<script type="text/javascript">
	$(document).ready(function(){
		function refreshTable() {
			$.ajax({    //create an ajax request to load_page.php
				type: "GET",
				url: "../proses/proses_tampil_peminjaman.php",   
				success: function(data){                    
					$("tbody#isi-table-peminjaman").html(data);
				}
	    	});
		}

		$("#form-tambah-peminjaman").submit(function() {
			var data_id_anggota = $("#input-tambah-peminjaman-id-anggota").val();
			var data_id_buku = $("#input-tambah-peminjaman-id-buku").val();
			$.ajax({    //create an ajax request to load_page.php
				type: "POST",
				url: "../proses/proses_tambah_peminjaman.php",             
				data: {id_anggota : data_id_anggota, id_buku : data_id_buku},
				success: function(data){
					refreshTable();
					$(".tambah-peminjaman-modal-lg").modal('hide');
					$("#form-tambah-peminjaman")[0].reset();
				}
	    	});
	    	return false;
		});

		$("#form-pengembalian").submit(function() {
			var data_id_peminjaman = $("#input-pengembalian-id-peminjaman").val();
			var data_id_buku = $("#input-pengembalian-id-buku").val();
			var data_denda = $("#input-pengembalian-denda").val();
			$.ajax({    //create an ajax request to load_page.php
				type: "POST",
				url: "../proses/proses_pengembalian_buku.php",             
				data: {id_peminjaman : data_id_peminjaman, id_buku : data_id_buku, denda : data_denda},
				success: function(data){
					refreshTable();
					$(".pengembalian-modal-lg").modal('hide');
					$("#form-pengembalian")[0].reset();
				}
	    	});
	    	return false;
		});

		refreshTable();
	});
</script>

<body>
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">SIPS</a>
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="navbar-collapse collapse" id="navbar-main">
				<ul class="nav navbar-nav">
					<li class="active"><a href="#">Dashboard<span class="sr-only">(current)</span></a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right">
					<li><a href="../proses/proses_logout.php">Keluar</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="container isi">
		<div class="jumbotron">
			<h2 style="font-weight: bold">Admin <small> - Dashboard</small></h2>
		</div>
		
		<div class="row">
			<div class="row">
			<div class="col-md-2">
				<ul class="nav nav-pills nav-stacked">
					<li class="active"><a href="#">Peminjaman</a></li>
					<li><a href="buku.php">Buku</a></li>
					<li><a href="anggota.php">Anggota</a></li>
					<li><a href="informasi.php">Informasi</a></li>
					<li><a href="kritiksaran.php">Kritik Saran</a></li>
					<li><a href="melapor.php">Laporan</a></li>
					<li><a href="requestbuku.php">Permintaan Tambahan Buku</a></li>
				</ul>
			</div>
			<div class="col-md-10">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h4 class="panel-title">Peminjaman
							<div class="btn-group pull-right">
								<a href="#" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".tambah-peminjaman-modal-lg"><span class="glyphicon glyphicon-plus"></span></a>
							</div>
						</h4>
						<div class="clearfix"></div>
					</div>
						<div class="panel-body">
							<form class="form-horizontal">
								<fieldset>
									<table class="table table-striped table-hover">
										<thead style="font-size: 14px">
											<tr>
												<th>ID Peminjaman</th>
												<th>ID Anggota</th>
												<th>ID Buku</th>
												<th>Judul Buku</th>
												<th>Tgl Pinjam</th>
												<th>Tgl Kembali</th>
												<th>Denda</th>
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody style="font-size: 13px" id="isi-table-peminjaman">
										</tbody>
									</table> 
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<br>
	<footer class="akhir">
		<div class="container">
			<br>
			<blockquote>Ini merupakan footer Sistem Informasi Perpustakaan Sekolah
				<small>Pengembangan Perangkat Lunak Agile</small>
			</blockquote>

			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
	</footer>

	<div class="modal fade tambah-peminjaman-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Tambah Peminjaman</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" method="POST" id="form-tambah-peminjaman" >
						<fieldset>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">ID Anggota</label>
								<div class="col-lg-10">
									<input name="id-anggota" class="form-control" id="input-tambah-peminjaman-id-anggota" placeholder="Masukkan ID Anggota" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">ID Buku</label>
								<div class="col-lg-10">
									<input name="id-buku" class="form-control" id="input-tambah-peminjaman-id-buku" placeholder="Masukkan ID Buku" type="text" required>
								</div>
							</div>
						</fieldset>
						<div class="modal-footer">
							<button name="submit" type="submit" class="btn btn-primary btn-pengembalian">Simpan Perubahan</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade pengembalian-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Pengembalian Buku</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" method="POST" id="form-pengembalian" >
						<fieldset>
							<div class="form-group">
								<label class="col-lg-2 control-label">ID Peminjaman</label>
								<div class="col-lg-10">
									<input name="id-peminjaman" class="form-control input-id-peminjaman" type="text" id="input-pengembalian-id-peminjaman" required readonly>
								</div>
							</div>

							<div class="form-group">
								<label class="col-lg-2 control-label">ID Buku</label>
								<div class="col-lg-10">
									<input name="id-buku" class="form-control input-id-buku" id="input-pengembalian-id-buku" type="text" required readonly>
								</div>
							</div>

							<div class="form-group">
								<label class="col-lg-2 control-label">Denda</label>
								<div class="col-lg-10">
									<input name="denda" class="form-control input-denda" id="input-pengembalian-denda" type="text" required readonly>
								</div>
							</div>
						</fieldset>
						<div class="modal-footer">
							<button name="submit" type="submit" class="btn btn-primary">Simpan Perubahan</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	</body>
</html>
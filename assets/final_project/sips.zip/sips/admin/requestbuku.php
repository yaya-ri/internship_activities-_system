<?php 
	require_once("../proses/koneksi.php");
	require_once("../proses/cek_login_admin.php");
	$query = mysqli_query($conn, "SELECT * FROM request_buku ");
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<title>Dashboard</title>
</head>

<body>
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">SIPS</a>
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="navbar-collapse collapse" id="navbar-main">
				<ul class="nav navbar-nav">
					<li class="active"><a href="#">Dashboard<span class="sr-only">(current)</span></a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right">
					<li><a href="../proses/proses_logout.php">Keluar</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="container isi">
		<div class="jumbotron">
			<h2 style="font-weight: bold">Admin <small> - Dashboard</small></h2>
		</div>

		<div class="row">
			<div class="row">
				<div class="col-md-2">
					<ul class="nav nav-pills nav-stacked">
						<li><a href="peminjaman.php">Peminjaman</a></li>
						<li><a href="buku.php">Buku</a></li>
						<li><a href="anggota.php">Anggota</a></li>
						<li><a href="informasi.php">Informasi</a></li>
						<li><a href="kritiksaran.php">Kritik Saran</a></li>
						<li><a href="melapor.php">Laporan</a></li>
						<li class="active"><a href="#">Permintaan Tambahan Buku</a></li>
					</ul>
				</div>
				<div class="col-md-10">
					<div class="panel panel-primary">
						<div class="panel-heading">
							<h4 class="panel-title">Permintaan Tambahan Buku</h4>
							<div class="clearfix"></div>
						</div>
						<div class="panel-body">
							<form class="form-horizontal">
								<fieldset>
									<table class="table table-striped table-hover">
										<thead style="font-size: 14px">
											<tr>
												<th>ID</th>
												<th>Identitas</th>
												<th>Isi Permintaan Buku</th>
												<th>Tanggal</th>
												<th>Aksi</th>
											</tr>
										</thead>
										<tbody style="font-size: 13px">
											<?php while ($request_buku = mysqli_fetch_array($query)) { ?>
											<tr>
												<td><?php echo $request_buku['id'];?></td>
												<td><?php echo $request_buku['identitas'];?></td>
												<td><?php echo $request_buku['isi'];?></td>
												<td><?php echo $request_buku['tanggal'];?></td>
												<td>
													<a class="btn btn-danger btn-xs" data-toggle="modal" data-target=".hapus-info-modal-lg" data-href="../proses/proses_hapus_req_buku.php?id=<?php echo $request_buku['id'];?>"><span class="glyphicon glyphicon-trash"></span>
													</a>
												</td>
											</tr>
										<?php } ?>
										</tbody>
									</table> 
								</fieldset>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade hapus-info-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Hapus Request Buku</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal">
						<fieldset>
							<p>Apakah Anda Yakin Untuk Menghapus Request Buku Ini ?</p>
						<div class="modal-footer">
							<a type="button" class="btn btn-primary btn-hapus">Simpan Perubahan</a>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	<br>
	<footer class="akhir">
		<div class="container">
			<br>
			<blockquote>Ini merupakan footer Sistem Informasi Perpustakaan Sekolah
				<small>Pengembangan Perangkat Lunak Agile</small>
			</blockquote>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
	</footer>
</body>
<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
<script type="text/javascript" src="../js/bootstrap.min.js"></script>
<script type="text/javascript" src="../js/crud.js"></script>
</html>
<?php 
	require_once("../proses/koneksi.php");
	require_once("../proses/cek_login.php");

	$query = mysqli_query($conn, "SELECT * FROM anggota WHERE id = '$id'");
	$query2 = mysqli_query($conn, "SELECT p.id, p.id_buku, b.judul, p.tgl_pinjam, p.tgl_kembali FROM peminjaman p JOIN buku b ON p.id_buku = b.id WHERE p.id_anggota = '$id' AND p.tgl_mengembalikan IS NULL ");
	$anggota = mysqli_fetch_array($query);
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<title>Dashboard</title>
</head>

<body>
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">SIPS</a>
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="navbar-collapse collapse" id="navbar-main">
				<ul class="nav navbar-nav">
					<li class="active"><a href="#">Dashboard<span class="sr-only">(current)</span></a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right">
					<li><a href="../proses/proses_logout.php">Keluar</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="konten">
		<div class="container isi">
			<div class="jumbotron">
				<h2 style="font-weight: bold">Hallo <small> - <?php echo $anggota['nama']; ?></small></h2>
			</div>

			<div class="row">
				<div class="row">
					<div class="col-md-2 menu-samping">
						<ul class="nav nav-pills nav-stacked">
							<li class="active"><a href="#">Daftar Pinjam</a></li>
							<li><a href="riwayat_pinjam.php">Riwayat Pinjam</a></li>
							<li><a href="pengaturan_akun.php">Pengaturan Akun</a></li>
						</ul>
					</div>
					<div class="col-md-10">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h4 class="panel-title">Daftar Buku Yang Sedang Dipinjam</h4>
								<div class="clearfix"></div>
							</div>
							<div class="panel-body">
								<form class="form-horizontal">
									<fieldset>
										<table class="table table-striped table-hover">
											<thead style="font-size: 14px">
												<tr>
													<th>ID Peminjaman</th>
													<th>ID Buku</th>
													<th>Judul Buku</th>
													<th>Tgl Pinjam</th>
													<th>Tgl Kembali</th>
													<th>Denda</th>
												</tr>
											</thead>
											<tbody style="font-size: 13px">
												<?php while($peminjaman = mysqli_fetch_array($query2)) { ?>
											<?php 
													$today = date_create(date('Y-m-d'));
													$kembali = date_create($peminjaman['tgl_kembali']);
													if($today > $kembali){
														$diff = date_diff($today, $kembali);
														$selisih = $diff->format('%a');
														$denda = $selisih * 1000;
														echo "<tr class='danger'>";
													} else {
														$denda = 0;
														echo "<tr>";
													}
													
												?>
												<td><?php echo $peminjaman['id']; ?></td>
												<td><?php echo $peminjaman['id_buku']; ?></td>
												<td><?php echo $peminjaman['judul']; ?></td>
												<td><?php echo $peminjaman['tgl_pinjam']; ?></td>
												<td><?php echo $peminjaman['tgl_kembali']; ?></td>
												<td><?php echo $denda ?></td>
											</tr>
										<?php } ?>
											</tbody>
										</table> 
									</fieldset>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<br>
	<footer class="akhir">
		<div class="container">
			<br>
			<blockquote>Ini merupakan footer Sistem Informasi Perpustakaan Sekolah
				<small>Pengembangan Perangkat Lunak Agile</small>
			</blockquote>

			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			</div>
		</footer>
	</body>
	<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../js/anggota.js"></script>
</html>
<?php 
	require_once("../proses/koneksi.php");
	require_once("../proses/cek_login.php");

	$query = mysqli_query($conn, "SELECT * FROM anggota WHERE id = '$id'");
	$anggota = mysqli_fetch_array($query);
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../css/style.css">
	<script type="text/javascript" src="../js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
	<script type="text/javascript" src="../js/anggota.js"></script>
	<title>Dashboard</title>
</head>

<body>
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<a href="#" class="navbar-brand">SIPS</a>
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="navbar-collapse collapse" id="navbar-main">
				<ul class="nav navbar-nav">
					<li class="active"><a href="#">Dashboard<span class="sr-only">(current)</span></a></li>
				</ul>

				<ul class="nav navbar-nav navbar-right">
					<li><a href="../proses/proses_logout.php">Keluar</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="konten">
		<div id="konten" class="container isi">
			<div class="jumbotron">
				<h2 style="font-weight: bold">Hallo <small> - <?php echo $anggota['nama']; ?></small></h2>
			</div>
			
			<div class="row">
				<div class="row">
					<div class="col-md-2 menu-samping">
						<ul class="nav nav-pills nav-stacked">
							<li><a href="daftar_pinjam.php">Daftar Pinjam</a></li>
							<li><a href="riwayat_pinjam.php">Riwayat Pinjam</a></li>
							<li class="active"><a href="#">Pengaturan Akun</a></li>
						</ul>
					</div>	
					<div class="col-md-10">
						<div class="panel panel-primary">
							<div class="panel-heading">
								<h4 class="panel-title">Akun Saya
									<div class="btn-group pull-right">
										<a href="#" class="btn btn-primary btn-xs" data-toggle="modal" data-target=".ubah-akun-modal-lg"><span class="glyphicon glyphicon-pencil"></span></a>
									</div>
								</h4>
								<div class="clearfix"></div>
							</div>
							<div class="panel-body">
								<form class="form-horizontal">
									<fieldset>
										<div class="form-group">
											<label for="inputidentitas" class="col-lg-2 control-label">ID</label>
											<div class="col-lg-10">
												<input class="form-control" id="input-identitas-kritiksaran" type="text" value="<?php echo $anggota['id'] ; ?>" readonly >
											</div>
										</div>
										<div class="form-group">
											<label for="inputidentitas" class="col-lg-2 control-label">Nama</label>
											<div class="col-lg-10">
												<input class="form-control" id="input-identitas-kritiksaran" type="text" value="<?php echo $anggota['nama'] ; ?>" readonly>
											</div>	
										</div>
										<div class="form-group">
											<label for="inputidentitas" class="col-lg-2 control-label">Alamat</label>
											<div class="col-lg-10">
												<input class="form-control" id="input-identitas-kritiksaran" type="text" value="<?php echo $anggota['alamat'] ; ?>" readonly>
											</div>
										</div>
										<div class="form-group">
											<label for="inputidentitas" class="col-lg-2 control-label">No.Hp</label>
											<div class="col-lg-10">
												<input class="form-control" id="input-identitas-kritiksaran" type="text" value="<?php echo $anggota['nohp'] ; ?>" readonly>
											</div>
										</div>
									</fieldset>
								</form>
							</div>
						</div>

						<div class="panel panel-primary">
							<div class="panel-heading">
								<h4 class="panel-title">Ubah Password</h4>
								<div class="clearfix"></div>
							</div>
							<div class="panel-body">
								<form class="form-horizontal" action="../proses/proses_ubah_password_anggota.php" method="POST">
									<fieldset>
										<div class="form-group">
											<label for="inputidentitas" class="col-lg-2 control-label">Password Lama</label>
											<div class="col-lg-10">
												<input name="password_lama_anggota" class="form-control" id="input-password-lama" type="password">
											</div>
										</div>
										<div class="form-group" id="password-baru">
											<label for="inputidentitas" class="col-lg-2 control-label">Password Baru</label>
											<div class="col-lg-10">
												<input name="password_baru_anggota" class="form-control" id="input-password-baru" type="password">
											</div>	
										</div>
										<div class="form-group" id="password-baru-lagi">
											<label for="inputidentitas" class="col-lg-2 control-label">Konfirmasi Password Baru</label>
											<div class="col-lg-10">
												<input name="password_baru_lagi_anggota" class="form-control" id="input-pasword-baru-lagi" type="password">
											</div>
										</div>
									</fieldset>
									<div class="modal-footer">
										<button type="submit" class="btn btn-primary" name="ubah-password-anggota">Simpan Perubahan</button>
										<button type="reset" class="btn btn-danger" data-dismiss="modal">Batal</button>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<br>
	<footer class="akhir">
		<div class="container">
			<br>
			<blockquote>Ini merupakan footer Sistem Informasi Perpustakaan Sekolah
				<small>Pengembangan Perangkat Lunak Agile</small>
			</blockquote>

			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
		</div>
	</footer>

	<div class="modal fade ubah-akun-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		<div class="modal-dialog modal-lg" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h4 class="modal-title">Ubah Identitas Akun</h4>
				</div>
				<div class="modal-body">
					<form class="form-horizontal" onsubmit="confirm('Are You Sure ?');" action="../proses/proses_ubah_data_anggota.php" method="POST">
						<fieldset>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">ID Anggota</label>
								<div class="col-lg-10">
									<input name="anggota-id" class="form-control" id="form-ubah-id-anggota" type="text" value="<?php echo $anggota['id']; ?>" readonly>
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Nama</label>
								<div class="col-lg-10">
									<input name="anggota-nama" class="form-control" id="form-ubah-nama-anggota" type="text" value="<?php echo $anggota['nama']; ?>">
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">Alamat</label>
								<div class="col-lg-10">
									<input name="anggota-alamat" class="form-control" id="form-ubah-alamat-anggota" type="text" value="<?php echo $anggota['alamat']; ?>">
								</div>
							</div>
							<div class="form-group">
								<label for="inputidentitas" class="col-lg-2 control-label">No.Hp</label>
								<div class="col-lg-10">
									<input name="anggota-nohp" class="form-control" id="form-ubah-nohp-anggota" type="text" value="<?php echo $anggota['nohp']; ?>">
								</div>
							</div>
						</fieldset>
						<div class="modal-footer">
							<button name="ubah-anggota" type="submit" id="form-ubah-submit-anggota" class="btn btn-primary">Simpan Perubahan</button>
							<button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
	</body>

</html>
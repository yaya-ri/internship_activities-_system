<?php
	session_start();
	include("proses/koneksi.php");
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	<title>Cari Buku</title>
</head>

<script type="text/javascript">
	$(document).ready(function() {
		$("#form_cari_buku").submit(function() {
			var data_pencarian = $("#form-pilihan-pencarian").val();
			var data_kata_kunci = $("#form-kata-kunci-pencarian").val();
			$.ajax({    //create an ajax request to load_page.php
				type: "POST",
				url: "proses/proses_cari_buku.php",             
				data: {pencarian : data_pencarian, kata_kunci : data_kata_kunci},
				success: function(response){                    
					$("tbody#isi_cari_buku").html(response);
				}
	    	});
	    	return false;
  		});
	});
</script>

<body>
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<a href="./" class="navbar-brand">SIPS</a>
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="navbar-collapse collapse" id="navbar-main">
				<ul class="nav navbar-nav">
					<li><a href="./">Beranda</a></li>
					<li class="active">
						<a href="#">Cari Buku</a>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" id="download">Layanan <span class="caret"></span></a>
						<ul class="dropdown-menu" aria-labelledby="download">
							<li><a href="kritiksaran.php">Kritik Saran</a></li>
							<li><a href="#">Melapor</a></li>
							<li><a href="#">Request Buku</a></li>
						</ul>
					</li>
				</ul>

				<ul class="nav navbar-nav navbar-right">
					<li><a href="login.php">Masuk</a></li>
				</ul>
			</div>
		</div>
	</div>

	<div class="container isi">
		<div class="jumbotron">
			<h2 style="font-weight: bold">Sistem Informasi Perpustakaan Sekolah <small>- Cari Buku</small></h2>
			<p>Cari.&emsp;Baca.&emsp;Pinjam.</p>
		</div>
		
		<div class="row">
			<div class="panel panel-primary">
				<div class="panel-heading">
					<legend class="panel-title">Pencarian Buku</legend>
				</div>
				<div class="panel-body">
					<form class="form-horizontal" method="POST" id="form_cari_buku">
						<fieldset>
							<div class="form-group">
								<label class="col-lg-2 control-label">Pilih Pencarian</label>
								<div class="col-lg-3">
									<select name="pencarian" class="form-control" id="form-pilihan-pencarian">
										<option value="">--Pilih Pencarian--</option>
										<option value="judul">Judul</option>
										<option value="kategori">Kategori</option>
										<option value="pengarang">Pengarang</option>
										<option value="penerbit">Penerbit</option>
										<option value="tahun_terbit">Tahun Terbit</option>
									</select>
								</div>
							</div>
							<div class="form-group">
								<label class="col-lg-2 control-label">Kata Kunci</label>
								<div class="col-lg-10">
									<input id="form-kata-kunci-pencarian" name="kata_kunci" class="form-control" placeholder="Masukkan Kata Kunci" type="text" required>
								</div>
							</div>
							<div class="form-group">
								<div class="col-lg-10 col-lg-offset-2">
									<button name="submit" type="submit" class="btn btn-primary">Submit</button>
									<button type="reset" class="btn btn-danger">Cancel</button>
								</div>
							</div>
						</fieldset>
					</form>
				</div>
			</div>
			<div class="panel panel-primary">
				<div class="panel-heading">
					<legend class="panel-title">Hasil Pencarian Buku</legend>
				</div>
				<div class="panel-body">
					<form class="form-horizontal">
						<fieldset>
							<table class="table table-striped table-hover ">
								<thead>
									<tr>
										<th>#</th>
										<th>Judul Buku</th>
										<th>Kategori</th>
										<th>Pengarang</th>
										<th>Penerbit</th>
										<th>Tahun Terbit</th>
										<th>Ketersediaan</th>
										<th>Lokasi</th>
									</tr>
								</thead>
								<tbody id="isi_cari_buku">
									
								</tbody>
							</table> 
						</fieldset>
					</form>
				</div>
			</div>
		</div>
	</div>
	<footer class="akhir">
		<div class="container">
			<br>
			<blockquote>Ini merupakan footer Sistem Informasi Perpustakaan Sekolah
				<small>Pengembangan Perangkat Lunak Agile</small>
			</blockquote>

			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
			</p>
		</div>
	</footer>
</body>

</html>
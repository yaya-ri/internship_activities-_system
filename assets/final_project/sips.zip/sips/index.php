<?php
	include("proses/koneksi.php");
	$query = mysqli_query($conn, "SELECT * FROM informasi");
	$query2 = mysqli_query($conn, "SELECT judul FROM buku WHERE tgl_masuk > (CURRENT_DATE - INTERVAL '2' WEEK)");
	session_start();
?>

<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<title>Beranda</title>
</head>

<body>
	<div class="navbar navbar-default navbar-fixed-top">
		<div class="container">
			<div class="navbar-header">
				<a href="." class="navbar-brand">SIPS</a>
				<button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-main">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="navbar-collapse collapse" id="navbar-main">
				<ul class="nav navbar-nav">
					<li class="active"><a href="#">Beranda<span class="sr-only">(current)</span></a></li>
					<li>
						<a href="caribuku.php">Cari Buku</a>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" id="download">Layanan <span class="caret"></span></a>
						<ul class="dropdown-menu" aria-labelledby="download">
							<li><a href="kritiksaran.php">Kritik Saran</a></li>
							<li><a href="#">Melapor</a></li>
							<li><a href="#">Request Buku</a></li>
						</ul>
					</li>
				</ul>

				<ul class="nav navbar-nav navbar-right">
					<li><a href="login.php">Masuk</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="container isi">
		<div class="jumbotron">
			<h2 style="font-weight: bold">Sistem Informasi Perpustakaan Sekolah <small> - Beranda</small></h2>
			<p>Cari.&emsp;Baca.&emsp;Pinjam.</p>
		</div>
		
		<div class="row">
			<div class="col-md-4">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Buku Terbaru</h3>
					</div>
					<div class="panel-body">
						<table class="table table-striped table-hover ">
							<tbody>
							<?php 
								$i = 1;
								while ($buku = mysqli_fetch_array($query2)) { ?>
								<tr>
									<td><?php echo "#".$i; ?></td>
									<td><?php echo $buku['judul']; ?></td>
									<?php $i++; ?>
								</tr>
							<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
			<div class="col-md-8">
				<div class="panel panel-primary">
					<div class="panel-heading">
						<h3 class="panel-title">Informasi Perpustakaan</h3>
					</div>
					<div class="panel-body">
						<table class="table table-striped table-hover ">
							<tbody>
								<?php while ($informasi = mysqli_fetch_array($query)) { ?>
									<tr>
										<td style="text-align: justify">
											<strong><?php echo $informasi['judul'];?></strong> (<?php echo $informasi['tanggal']; ?>)<br>
											<?php echo $informasi['isi']; ?>
										</td>
									</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>
	<footer class="akhir">
		<div class="container">
			<br>
			<blockquote>Ini merupakan footer Sistem Informasi Perpustakaan Sekolah
				<small>Pengembangan Perangkat Lunak Agile</small>
			</blockquote>

			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
				tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
				quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
				consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
				cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
				proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>
			</div>
		</footer>
	</body>
	<script type="text/javascript" src="js/jquery-3.1.1.min.js"></script>
	<script type="text/javascript" src="js/bootstrap.min.js"></script>
	</html>
$(document).ready(function(){
	$(".ajax-button").click(function(){
		$(".content").load("login.php");
	});
});
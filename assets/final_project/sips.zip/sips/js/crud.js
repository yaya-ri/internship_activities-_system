$(document).ready(function(){
	
	$(".hapus-data-buku-modal-lg").on('shown.bs.modal', function(e){
		var baris = $(e.relatedTarget).closest("tr");
		var id = baris.find("td").eq(0).html();
		var modal = $(this);

		modal.find("#input-hapus-id-buku").val(id);
	});

	$(".ubah-data-buku-modal-lg").on('shown.bs.modal', function(e){
		var baris = $(e.relatedTarget).closest("tr");
		var id = baris.find("td").eq(0).html();
		var judul = baris.find("td").eq(1).html();
		var kategori = baris.find("td").eq(2).html();
		var pengarang = baris.find("td").eq(3).html();
		var penerbit = baris.find("td").eq(4).html();
		var tahun_terbit = baris.find("td").eq(5).html();
		var tanggal_masuk = baris.find("td").eq(6).html();
		var stok = baris.find("td").eq(7).html();
		var ketersediaan = baris.find("td").eq(8).html();
		var lokasi = baris.find("td").eq(9).html();

		var modal = $(this);

		modal.find(".input-id").val(id);
		modal.find(".input-judul").val(judul);
		modal.find(".input-kategori").val(kategori);
		modal.find(".input-pengarang").val(pengarang);
		modal.find(".input-penerbit").val(penerbit);
		modal.find(".input-tahun-terbit").val(tahun_terbit);
		modal.find(".input-tanggal-masuk").val(tanggal_masuk);
		modal.find(".input-stok").val(stok);
		modal.find(".input-ketersediaan").val(ketersediaan);
		modal.find(".input-lokasi").val(lokasi);
	});


	$(".pengembalian-modal-lg").on('shown.bs.modal', function(e){
		var baris = $(e.relatedTarget).closest("tr");
		var id = baris.find("td").eq(0).html();
		var id_buku = baris.find("td").eq(2).html();
		var denda = baris.find("td").eq(6).html();

		var modal = $(this);

		modal.find(".input-id-peminjaman").val(id);
		modal.find(".input-id-buku").val(id_buku);
		modal.find(".input-denda").val(denda);
	});

	$(".reset-modal-lg").on('shown.bs.modal', function(e){
		var baris = $(e.relatedTarget).closest("tr");
		var id = baris.find("td").eq(0).html();
		var modal = $(this);
		modal.find(".input-id-anggota").val(id);
	});

	$(".hapus-anggota-modal-lg").on('shown.bs.modal', function(e){
		var baris = $(e.relatedTarget).closest("tr");
		var id = baris.find("td").eq(0).html();
		var modal = $(this);
		modal.find(".input-id-anggota").val(id);
	});

	$(".ubah-info-modal-lg").on('shown.bs.modal', function(e){
		var baris = $(e.relatedTarget).closest("tr");
		var id = baris.find("td").eq(0).html();
		var judul = baris.find("td").eq(1).html();
		var isi = baris.find("td").eq(2).html();

		var modal = $(this);

		modal.find(".input-id").val(id);
		modal.find(".input-judul").val(judul);
		modal.find(".input-isi").val(isi);
	});

	$(".hapus-info-modal-lg").on('shown.bs.modal', function(e){
		var baris = $(e.relatedTarget).closest("tr");
		var id = baris.find("td").eq(0).html();
		var modal = $(this);

		modal.find("#input-hapus-id-info").val(id);
	});

});
<?php
	session_start();
	if(!isset($_SESSION['id'])){
		echo "<script> alert('Silahkan Login Terlebih Dahulu');
		window.location.href='../login.php' </script>";
	} else {
		$id = $_SESSION['id'];
		$password = $_SESSION['password'];
	}
?>
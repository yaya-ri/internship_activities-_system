<?php
	session_start();
	if(!isset($_SESSION['username'])){
		echo "<script> alert('Silahkan Login Terlebih Dahulu');
		window.location.href='../admin/' </script>";
	} else {
		$id = $_SESSION['id'];
		$username = $_SESSION['username'];
	}
?>
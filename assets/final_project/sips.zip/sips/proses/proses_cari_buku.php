<?php 
	include("koneksi.php");
	$pencarian = $_POST['pencarian'];
	$kata_kunci = $_POST['kata_kunci'];

	if($pencarian != ""){
		if($pencarian == 'tahun_terbit'){
			$query = mysqli_query($conn, "SELECT * FROM buku WHERE tahun_terbit = '$kata_kunci'");
		} else {
			$query = mysqli_query($conn, "SELECT * FROM buku WHERE $pencarian LIKE '%$kata_kunci%'");	
		}
		$i = 1;
		while($buku = mysqli_fetch_array($query)){
			echo "<tr>";
			echo "<td>".$i."</td>";
			echo "<td>".$buku['judul']."</td>";
			echo "<td>".$buku['kategori']."</td>";
			echo "<td>".$buku['pengarang']."</td>";
			echo "<td>".$buku['penerbit']."</td>";
			echo "<td>".$buku['tahun_terbit']."</td>";
			echo "<td>".$buku['ketersediaan']."</td>";
			echo "<td>".$buku['lokasi']."</td>";
			echo "</tr>";
			$i++;
		}
	}
?>

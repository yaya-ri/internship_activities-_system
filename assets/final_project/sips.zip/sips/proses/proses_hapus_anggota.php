<?php 
	include("koneksi.php");
	include("cek_login_admin.php");
	
	$id = $_POST['id'];
	mysqli_query($conn, "DELETE FROM anggota where id = '$id'");
?>
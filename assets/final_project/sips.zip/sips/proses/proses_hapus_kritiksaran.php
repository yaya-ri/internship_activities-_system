<?php
	include('koneksi.php');
	include("cek_login_admin.php");
	
	$id = $_GET['id'];
	mysqli_query($conn, "DELETE FROM kritiksaran WHERE id = '$id'");
	echo "<script> window.location.href='../admin/kritiksaran.php' </script>";
?>
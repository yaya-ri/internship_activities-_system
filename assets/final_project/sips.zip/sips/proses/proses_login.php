<?php
	include("koneksi.php");
	$id = ($_POST['id']);
	$password = ($_POST['password']);

	if(isset($_POST['login'])){
		$sql = mysqli_query($conn, "SELECT * FROM anggota WHERE id = '$id' and password = '$password'");
		$result = mysqli_fetch_array($sql);

		if($result){
			session_start();
			$_SESSION['id'] = $result['id'];
			$_SESSION['password'] = $result['password'];
			$_SESSION['nama'] = $result['nama'];
			echo "<script> window.location.href='../anggota/daftar_pinjam.php' </script>";

		} else {
			echo "<script> alert('Username atau Password anda salah !!');
				window.location.href='../login.php' </script>";
		}
	}
 ?>
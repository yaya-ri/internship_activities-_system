<?php
	include("koneksi.php");
	$username = ($_POST['username']);
	$password = ($_POST['password']);

	if(isset($_POST['submit'])){
		$sql = mysqli_query($conn, "SELECT * FROM admin WHERE username = '$username' and password = '$password'");
		$result = mysqli_fetch_array($sql);

		if($result){
			session_start();
			$_SESSION['id'] = $result['id'];
			$_SESSION['username'] = $username;
			$_SESSION['password'] = $password;

			echo "<script> window.location.href='../admin/peminjaman.php' </script>";

		} else {
			echo "<script> alert('Username atau Password anda salah !!');
				window.location.href='../admin/index.php' </script>";
		}
	}
 ?>
<?php
	session_start();
	if(isset($_SESSION['id'])){
		session_destroy();
		echo "<script> alert('Anda Berhasil Logout'); window.location = '../'; </script>";
	}
?>
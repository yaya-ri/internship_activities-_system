<?php
	include('koneksi.php');
	include("cek_login_admin.php");

	$id_peminjaman = $_POST['id_peminjaman'];
	$denda = $_POST['denda'];
	$id_buku = $_POST['id_buku'];
	mysqli_query($conn, "UPDATE buku SET ketersediaan = ketersediaan+1 WHERE id = '$id_buku'");
	mysqli_query($conn, "UPDATE peminjaman SET tgl_mengembalikan = curdate(), denda = '$denda' WHERE id = '$id_peminjaman'");
	
?>
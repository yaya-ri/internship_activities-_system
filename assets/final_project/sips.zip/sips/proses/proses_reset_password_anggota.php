<?php 
	include("koneksi.php");
	include("cek_login_admin.php");
	
	$id = $_POST['id'];
	$password = "123456";
	mysqli_query($conn, "UPDATE anggota SET password = '$password' WHERE id = '$id'");
?>
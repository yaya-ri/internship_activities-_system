<?php 
	include("koneksi.php");
	include("cek_login_admin.php");

	$id = $_POST['id'];
	$password = "123456";
	$nama = $_POST['nama'];
	$alamat = $_POST['alamat'];
	$nohp = $_POST['nohp'];

	mysqli_query($conn, "INSERT INTO anggota (id, password, nama, alamat, nohp) VALUES ('$id', '$password', '$nama', '$alamat', '$nohp')");
	
?>
<?php 
	include("koneksi.php");
	include("cek_login_admin.php");

	$judul = $_POST['judul'];
	$kategori = $_POST['kategori'];
	$pengarang = $_POST['pengarang'];
	$penerbit = $_POST['penerbit'];
	$tahun_terbit = $_POST['tahun'];
	$tanggal_masuk = $_POST['tanggal_masuk'];
	$stok = $_POST['stok'];
	$lokasi = $_POST['lokasi'];
	$ketersediaan = $stok;

	mysqli_query($conn, "INSERT INTO buku (judul, kategori, pengarang, penerbit, tahun_terbit, tgl_masuk, stok, ketersediaan, lokasi) VALUES ('$judul', '$kategori', '$pengarang', '$penerbit', '$tahun_terbit', '$tanggal_masuk', '$stok', '$ketersediaan', '$lokasi')");
	echo "<script>window.alert('Data Buku Berhasil Ditambah');</script>";
	

	// echo "<script> window.location.href='../admin/buku.php' </script>";
?>
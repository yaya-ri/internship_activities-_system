<?php 
	include("koneksi.php");
	include("cek_login_admin.php");

	$judul = $_POST['judul'];
	$isi = $_POST['isi'];
	mysqli_query($conn, "INSERT INTO informasi (judul, isi, tanggal) VALUES ('$judul', '$isi', curdate())");
?>
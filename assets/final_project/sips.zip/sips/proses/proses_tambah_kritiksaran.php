<?php 
	include("koneksi.php");

	if(isset($_POST['tambah-kritiksaran'])){
		$nama = $_POST['nama'];
		$isi = $_POST['isi'];

		mysqli_query($conn, "INSERT INTO kritiksaran (identitas, isi, tanggal) VALUES ('$nama', '$isi', curdate())");
		echo "<script>window.alert('kritik & saran Berhasil Ditambah');</script>";
	} else {
		echo "<script>window.alert('kritik & saran Gagal Ditambah');</script>";
	}

	echo "<script> window.location.href='../kritiksaran.php' </script>";
?>
<?php 
	include("koneksi.php");

	if(isset($_POST['tambah-melapor'])){
		$nama = $_POST['nama'];
		$isi = $_POST['isi'];

		mysqli_query($conn, "INSERT INTO laporan (identitas, isi, tanggal) VALUES ('$nama', '$isi', curdate())");
		echo "<script>window.alert('Laporan Berhasil Ditambah');</script>";
	} else {
		echo "<script>window.alert('Laporan Gagal Ditambah');</script>";
	}

	echo "<script> window.location.href='../melapor.php' </script>";
?>
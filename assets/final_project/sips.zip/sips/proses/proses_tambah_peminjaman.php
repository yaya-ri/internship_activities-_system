<?php 
	include("koneksi.php");
	include("cek_login_admin.php");


		$id_anggota = $_POST['id_anggota'];
		$id_buku = $_POST['id_buku'];
		$tgl_pinjam = date('Y-m-d');
		$tgl_kembali = date('Y-m-d', strtotime('+10 days', strtotime($tgl_pinjam)));

		$query = mysqli_query($conn, "SELECT ketersediaan FROM buku WHERE id = '$id_buku'");
		$result = mysqli_fetch_array($query);
		if($result['ketersediaan'] != 0){
			mysqli_query($conn, "UPDATE buku SET ketersediaan = ketersediaan-1 WHERE id = '$id_buku'");
			mysqli_query($conn, "INSERT INTO peminjaman (id_anggota, id_buku, tgl_pinjam, tgl_kembali, denda) VALUES ('$id_anggota', '$id_buku', '$tgl_pinjam', '$tgl_kembali','0')");
			echo "<script>window.alert('Data Peminjaman Berhasil Ditambah');</script>";
		} else {
			echo "<script>window.alert('Buku tidak tersedia di perpustakaan');</script>";
		}
	

	//echo "<script> window.location.href='../admin/peminjaman.php' </script>";
?>
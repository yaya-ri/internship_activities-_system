<?php 
	include("koneksi.php");

	if(isset($_POST['tambah-reqBuku'])){
		$nama = $_POST['nama'];
		$isi = $_POST['isi'];

		mysqli_query($conn, "INSERT INTO request_buku (identitas, isi, tanggal) VALUES ('$nama', '$isi', curdate())");
		echo "<script>window.alert('Request Buku Berhasil Ditambah');</script>";
	} else {
		echo "<script>window.alert('Request Buku Gagal Ditambah');</script>";
	}

	echo "<script> window.location.href='../req_buku.php' </script>";
?>
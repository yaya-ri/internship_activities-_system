<?php
	include("koneksi.php");
	include("cek_login_admin.php");
	$query = mysqli_query($conn, "SELECT * FROM anggota");
?>

<?php 	 while ($anggota = mysqli_fetch_array($query)) { ?>
			<tr>
				<td><?php echo $anggota['id']; ?></td>
				<td><?php echo $anggota['nama']; ?></td>
				<td><?php echo $anggota['alamat']; ?></td>
				<td><?php echo $anggota['nohp']; ?></td>
				<td>
					<a class="btn btn-success btn-xs" data-toggle="modal" data-target=".reset-modal-lg"><span class="glyphicon glyphicon-refresh"></span></a>
					<a class="btn btn-danger btn-xs" data-toggle="modal" data-target=".hapus-anggota-modal-lg"><span class="glyphicon glyphicon-trash"></span></a>
				</td>
			</tr>

<?php } ?>
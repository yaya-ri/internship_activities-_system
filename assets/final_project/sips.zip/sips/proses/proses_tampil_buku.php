<?php
	include("koneksi.php");
	include("cek_login_admin.php");
	$query = mysqli_query($conn, "SELECT * FROM buku");
?>

<?php while($buku = mysqli_fetch_array($query)) { ?>
	<tr>
		<td><?php echo $buku['id']; ?></td>
		<td><?php echo $buku['judul']; ?></td>
		<td><?php echo $buku['kategori']; ?></td>
		<td><?php echo $buku['pengarang']; ?></td>
		<td><?php echo $buku['penerbit']; ?></td>
		<td><?php echo $buku['tahun_terbit']; ?></td>
		<td><?php echo $buku['tgl_masuk']; ?></td>
		<td><?php echo $buku['stok']; ?></td>
		<td><?php echo $buku['ketersediaan']; ?></td>
		<td><?php echo $buku['lokasi']; ?></td>
		<td>
			<a class="btn btn-success btn-xs" data-toggle="modal" data-target=".ubah-data-buku-modal-lg"><span class="glyphicon glyphicon-pencil"></span></a>
			<a class="btn btn-danger btn-xs" data-toggle="modal" data-target=".hapus-data-buku-modal-lg"><span class="glyphicon glyphicon-trash"></span></a>
		</td>
	</tr>
<?php } ?>
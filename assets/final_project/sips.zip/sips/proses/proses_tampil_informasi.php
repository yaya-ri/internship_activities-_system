<?php
	include("koneksi.php");
	include("cek_login_admin.php");
	$query = mysqli_query($conn, "SELECT * FROM informasi");
?>
<?php while($informasi = mysqli_fetch_array($query)) { ?>
<tr>
	<td><?php echo $informasi['id']; ?></td>
	<td><?php echo $informasi['judul']; ?></td>
	<td><?php echo $informasi['isi']; ?></td>
	<td><?php echo $informasi['tanggal']; ?></td>
	<td>
		<a class="btn btn-success btn-xs" data-toggle="modal" data-target=".ubah-info-modal-lg"><span class="glyphicon glyphicon-pencil"></span></a>  
		<a class="btn btn-danger btn-xs" data-toggle="modal" data-target=".hapus-info-modal-lg"><span class="glyphicon glyphicon-trash"></span>
		</a>
	</td>
</tr>
<?php } ?>
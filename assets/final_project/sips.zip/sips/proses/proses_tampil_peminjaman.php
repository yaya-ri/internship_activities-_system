<?php
	include("koneksi.php");
	include("cek_login_admin.php");
	$query = mysqli_query($conn, "SELECT p.id, p.id_anggota, p.id_buku, b.judul, p.tgl_pinjam, p.tgl_kembali, p.denda FROM peminjaman p JOIN buku b ON p.id_buku = b.id WHERE p.tgl_mengembalikan IS NULL");
?>

<?php while($peminjaman = mysqli_fetch_array($query)) { 
		$today = date_create(date('Y-m-d'));
		$kembali = date_create($peminjaman['tgl_kembali']);
		if($today > $kembali){
			$diff = date_diff($today, $kembali);
			$selisih = $diff->format('%a');
			$denda = $selisih * 1000;
			echo "<tr class='danger'>";
		} else {
			$denda = 0;
			echo "<tr>";
		}
	?>
	<td><?php echo $peminjaman['id']; ?></td>
	<td><?php echo $peminjaman['id_anggota']; ?></td>
	<td><?php echo $peminjaman['id_buku']; ?></td>
	<td><?php echo $peminjaman['judul']; ?></td>
	<td><?php echo $peminjaman['tgl_pinjam']; ?></td>
	<td><?php echo $peminjaman['tgl_kembali']; ?></td>
	<td><?php echo $denda ?></td>
	<td><a data-href="../proses/proses_pengembalian_buku.php?id=<?php echo $peminjaman['id']; ?>" class="btn btn-success btn-xs" data-toggle="modal" data-target=".pengembalian-modal-lg"><span class="glyphicon glyphicon-ok"></span></a></td>
</tr>
<?php } ?>
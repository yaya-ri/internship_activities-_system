<?php 
	include("koneksi.php");
	include("cek_login_admin.php");

	$id_buku = $_POST['id'];
	$judul = $_POST['judul'];
	$kategori = $_POST['kategori'];
	$pengarang = $_POST['pengarang'];
	$penerbit = $_POST['penerbit'];
	$tahun_terbit = $_POST['tahun'];
	$tanggal_masuk = $_POST['tanggal_masuk'];
	$stok = $_POST['stok'];
	$lokasi = $_POST['lokasi'];
	$ketersediaan = $_POST['ketersediaan'];

	mysqli_query($conn, "UPDATE buku SET judul = '$judul', kategori = '$kategori', pengarang = '$pengarang', penerbit = '$penerbit', tahun_terbit = '$tahun_terbit', tgl_masuk = '$tanggal_masuk', stok = '$stok', ketersediaan = '$ketersediaan', lokasi = '$lokasi' WHERE id = '$id_buku' ");
		
?>
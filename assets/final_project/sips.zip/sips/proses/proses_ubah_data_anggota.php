<?php 
	include("koneksi.php");
	include("cek_login.php");

	if(isset($_POST['ubah-anggota'])){
		$nama = $_POST['anggota-nama'];
		$alamat = $_POST['anggota-alamat'];
		$nohp = $_POST['anggota-nohp'];
		mysqli_query($conn, "UPDATE anggota SET nama='$nama', alamat='$alamat', nohp='$nohp' WHERE id='$id'");
		echo "<script>window.alert('Data Pribadi Anda Berhasil Diubah');</script>";
	}

	echo "<script> window.location.href='../anggota/pengaturan_akun.php' </script>";
?>
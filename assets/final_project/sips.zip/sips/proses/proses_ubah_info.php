<?php 
	include("koneksi.php");
	include("cek_login_admin.php");

	$id_info = $_POST['id'];
	$judul = $_POST['judul'];
	$isi = $_POST['isi'];
	mysqli_query($conn, "UPDATE informasi SET judul='$judul', isi='$isi' WHERE id='$id_info'");
?>
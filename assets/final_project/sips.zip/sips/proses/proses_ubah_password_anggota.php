<?php 
	include("koneksi.php");
	include("cek_login.php");

	if(isset($_POST['ubah-password-anggota'])){
		$password_lama = $_POST['password_lama_anggota'];
		$password_baru = $_POST['password_baru_anggota'];
		$password_baru_lagi = $_POST['password_baru_lagi_anggota'];

		$query = mysqli_query($conn, "SELECT * FROM anggota WHERE id = '$id'");
		$anggota = mysqli_fetch_array($query);

		if($anggota['password'] == $password_lama && $password_baru == $password_baru_lagi){
			mysqli_query($conn, "UPDATE anggota SET password='$password_baru' WHERE id='$id'");
			echo "<script>window.alert('Password Anda Berhasil Diubah');</script>";
			echo "<script> window.location.href='../login.php' </script>";
		} else {
			echo "<script>window.alert('Password Anda Gagal Diubah');</script>";
			echo "<script> window.location.href='../anggota/pengaturan_akun.php' </script>";
		}
	}
	
?>